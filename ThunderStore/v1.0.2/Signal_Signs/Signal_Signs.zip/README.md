# Peak Signs

Adds wall-aligned signs and arrows to PEAK.

## Features
- Place signs and arrows using the middle mouse button
- Signs align correctly to walls and surfaces
- Placed signs can be deleted again
- Signs use the color of the player who placed them
- Arrow aligns parallel to the surface
- Multiplayer compatible
## Controls
- Hold Middle Mouse Button – Place a sign
- Hold Middle Mouse Button on sign – Delete a sign

## Installation
Requires BepInEx
Extract the mod into your BepInEx/plugins folder

## Credits
Created by Mitschpielen