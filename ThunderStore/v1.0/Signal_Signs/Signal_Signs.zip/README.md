# Peak Signs

Adds wall-aligned signs and arrows to PEAK.

## Features
- Place signs on walls
- Arrow aligns parallel to the surface
- Multiplayer compatible

## Installation
Requires BepInEx.

## Credits
Created by Mitschpielen
